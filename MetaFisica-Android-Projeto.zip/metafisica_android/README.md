# Meta Física — projeto Android

Projeto Android simples que mostra a aplicação local `index.html` num WebView nativo, com suporte para abrir o seletor de imagens do Android.

## Recursos
- Diário de refeições com foto da câmera/galeria.
- Campos opcionais para estimativas nutricionais por refeição.
- Hidratação, humor, atividades e diário pessoal.
- Persistência local via `localStorage`.
- Exportação dos registros em JSON.

**Limitação importante:** a foto é guardada, mas não existe reconhecimento automático de alimentos nem cálculo de nutrientes por IA nesta versão. Isso exige integrar e configurar um serviço de IA.

## APK
O ambiente desta sessão não contém Android SDK/Gradle. O fluxo `.github/workflows/build-apk.yml` compila um APK debug no GitHub Actions com Android SDK, JDK 17, AGP 9.5.0 e Gradle 9.6.0. Consulte `LEIA-ME-ANTES.txt` para as etapas pelo celular.
